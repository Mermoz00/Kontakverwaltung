var express = require('express');
var router = express.Router();
const title = "Kontakt"
const users = require("./contacts")
/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('pages/contact/showAll', {
    users: users,
    title: title
  });
});

router.get('/showall', function (req, res, next) {
  res.render('pages/contact/showAll', {
    users: users,
    title: title
  });
});

router.get('/show/:id', function (req, res, next) {
  res.render('pages/contact/show', {
    users: users,
    id: req.params.id,
    title: title
  });
});

router.get('/newcontact', function (req, res, next) {
  res.render('pages/contact/add', {
    title: 'Express'
  });
});

module.exports = router;
